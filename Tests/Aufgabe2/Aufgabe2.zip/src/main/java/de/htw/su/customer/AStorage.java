package de.htw.su.customer;

/**
 * comment about this class
 *
 * @author Alexander Tiedmann (s0556127)
 * @version 1.0
 * @since 29.05.2017
 */
public abstract class AStorage {

  public String save(String s) {
    // Only a dummy return. Not important for our context.
    return s;
  }
}
