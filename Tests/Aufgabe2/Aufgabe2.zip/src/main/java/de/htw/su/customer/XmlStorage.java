package de.htw.su.customer;

/**
 * comment about this class
 *
 * @author Alexander Tiedmann (s0556127)
 * @version 1.0
 * @since 29.05.2017
 */
public class XmlStorage extends AStorage {

  public String save(String s) {
    return s + " saved in a XML file.";
  }
}
