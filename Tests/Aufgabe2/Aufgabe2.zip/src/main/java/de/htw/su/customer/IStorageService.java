package de.htw.su.customer;

/**
 * comment about this class
 *
 * @author Alexander Tiedmann (s0556127)
 * @version 1.0
 * @since 29.05.2017
 */
public interface IStorageService {

  public AStorage createStorage(StorageType storageType);

}
